# MTS
Je précise qu'il a été modifié.

## Installation

Veuillez installer les modules suivants:

```
npm install 
npm install discord.js@12.5.3
```

## Usage

Après avoir installer les modules faites:

```Node .
# Remplissez les informations dans le fichier
config.json


# Token
Mettez le token de votre bot

# ID (Owners)
Mettez les ID des propriétaires du bot !
```
## Serveur

> Rejoignez notre serveur discord pour avoir de l'aide !
[Développement France](https://discord.gg/D4ZmrctRaN)

